import React from 'react';
import PlayButton from './PlayButton';
import StatusIndicator from './StatusIndicator';
import '../assets/styles/lightglass.css';

const Dashboard: React.FC = () => (
  <div className="dashboard">
    <h1>Smart Mobile Pro</h1>
    <StatusIndicator />
    <PlayButton />
  </div>
);

export default Dashboard;