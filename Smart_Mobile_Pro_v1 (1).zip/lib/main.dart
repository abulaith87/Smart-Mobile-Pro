import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Simple prototype UI for Smart Mobile Pro
void main() {
  runApp(const SmartMobileProApp());
}

class SmartMobileProApp extends StatelessWidget {
  const SmartMobileProApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Smart Mobile Pro',
      theme: ThemeData.light().copyWith(
        primaryColor: Color(0xFF0B69FF),
        scaffoldBackgroundColor: Color(0xFFF7FBFF),
        cardTheme: CardTheme(elevation: 6, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
      ),
      home: const DashboardPage(),
    );
  }
}

class ProjectItem {
  final int id;
  final String name;
  final String runtime;
  final int minIncome;
  final int maxIncome;
  String status;
  List<String> keysRequired;

  ProjectItem(this.id, this.name, this.runtime, this.minIncome, this.maxIncome, this.status, this.keysRequired);

  Map<String,dynamic> toJson() => {
    'id': id, 'name': name, 'runtime': runtime, 'minIncome': minIncome, 'maxIncome': maxIncome,
    'status': status, 'keysRequired': keysRequired
  };
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final storage = const FlutterSecureStorage(); // for keys
  List<ProjectItem> projects = [];

  @override
  void initState() {
    super.initState();
    loadProjects();
  }

  void loadProjects() {
    projects = [
      ProjectItem(1, 'Auto Viral Video Lab', '08:00-09:00', 600, 2200, 'stopped', [
        'OPENAI_API_KEY','ELEVENLABS_API_KEY','JSON2VIDEO_API_KEY','YOUTUBE_API_KEY','STRIPE_SECRET_KEY','TELEGRAM_BOT_TOKEN','TIKTOK_CLIENT_KEY','TIKTOK_CLIENT_SECRET']),
      ProjectItem(2, 'AI Course Factory', '09:00-10:00', 500, 1800, 'stopped', [
        'OPENAI_API_KEY','ELEVENLABS_API_KEY','JSON2VIDEO_API_KEY','STRIPE_SECRET_KEY','TELEGRAM_BOT_TOKEN']),
      ProjectItem(3, 'Mobile SaaS Tools Empire', '10:00-11:00', 800, 3500, 'stopped', ['OPENAI_API_KEY','STRIPE_SECRET_KEY','TELEGRAM_BOT_TOKEN']),
      ProjectItem(4, 'Dream2Script', '11:00-12:00', 400, 1200, 'stopped', ['OPENAI_API_KEY']),
      ProjectItem(5, 'DreamMail', '12:00-13:00', 300, 900, 'stopped', ['OPENAI_API_KEY']),
      ProjectItem(6, 'ZeroSkill Market', '13:00-14:00', 450, 1500, 'stopped', ['OPENAI_API_KEY','STRIPE_SECRET_KEY']),
      ProjectItem(7, 'MindQuest AR', '14:00-15:00', 250, 1000, 'stopped', ['OPENAI_API_KEY']),
      ProjectItem(8, 'WorldSeed', '15:00-16:00', 200, 700, 'stopped', ['OPENAI_API_KEY']),
    ];
    setState(() {});
  }

  Future<Map<String,String>> loadKeys(int id) async {
    final val = await storage.read(key: 'project_keys_$id');
    if (val==null) return {};
    return Map<String,String>.from(jsonDecode(val));
  }

  Future<void> saveKeys(int id, Map<String,String> keys) async {
    await storage.write(key: 'project_keys_$id', value: jsonEncode(keys));
    setState(() {});
  }

  Widget statusBadge(String status) {
    Color bg; Color txt;
    switch(status){
      case 'running': bg=Colors.lightBlue.shade50; txt=Colors.blue.shade900; break;
      case 'idle': bg=Colors.orange.shade50; txt=Colors.orange.shade900; break;
      default: bg=Colors.pink.shade50; txt=Colors.pink.shade900; break;
    }
    return Container(padding: const EdgeInsets.symmetric(horizontal:8,vertical:6), decoration: BoxDecoration(color:bg,borderRadius: BorderRadius.circular(999)), child: Text(status, style: TextStyle(color:txt,fontWeight:FontWeight.w600)));
  }

  void openKeysEditor(ProjectItem p) async {
    final existing = await loadKeys(p.id);
    final controller = <String,TextEditingController>{};
    for (var k in p.keysRequired) controller[k]=TextEditingController(text: existing[k]??'');
    showDialog(context: context, builder: (_){
      return AlertDialog(
        title: Text('Manage keys — ${p.name}'),
        content: SizedBox(width: double.maxFinite, child: SingleChildScrollView(child: Column(
          children: p.keysRequired.map((k)=> Padding(padding: const EdgeInsets.symmetric(vertical:6), child:
            TextField(controller: controller[k], decoration: InputDecoration(labelText: k, border: OutlineInputBorder())))).toList()))),
        actions: [
          TextButton(onPressed: ()=>Navigator.pop(context), child: const Text('إلغاء')),
          ElevatedButton(onPressed: () async {
            final map = <String,String>{};
            controller.forEach((k,c){ if (c.text.trim().isNotEmpty) map[k]=c.text.trim(); });
            await saveKeys(p.id, map);
            Navigator.pop(context);
          }, child: const Text('حفظ')),
        ],
      );
    });
  }

  void runAll() async {
    for (var p in projects) {
      final keys = await loadKeys(p.id);
      final missing = p.keysRequired.where((k)=> !(keys.containsKey(k) && keys[k]!.length>5)).toList();
      if (missing.isNotEmpty) {
        p.status='stopped';
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${p.name} - مفاتيح ناقصة: ${missing.join(', ')}')));
      } else {
        p.status='running';
        setState(() {});
        await Future.delayed(const Duration(milliseconds: 600));
      }
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Smart Mobile Pro'), backgroundColor: const Color(0xFF0B69FF)),
      body: Padding(padding: const EdgeInsets.all(12), child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          ElevatedButton.icon(onPressed: runAll, icon: const Icon(Icons.play_arrow), label: const Text('تشغيل الكل')),
          ElevatedButton.icon(onPressed: (){ for(var p in projects) p.status='stopped'; setState((){}); }, icon: const Icon(Icons.stop), label: const Text('إيقاف الكل'), style: ElevatedButton.styleFrom(backgroundColor: Colors.orange)),
          ElevatedButton.icon(onPressed: (){ for(var p in projects) p.status='idle'; setState((){}); }, icon: const Icon(Icons.refresh), label: const Text('فحص الآن'), style: ElevatedButton.styleFrom(backgroundColor: Colors.grey)),
        ]),
        const SizedBox(height:12),
        Expanded(child: ListView.builder(itemCount: projects.length, itemBuilder: (_,i){
          final p = projects[i];
          return Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(p.name, style: const TextStyle(fontSize:16,fontWeight: FontWeight.w600)), statusBadge(p.status)]),
            const SizedBox(height:6),
            Text('نسبة نجاح: ${p.minIncome}–${p.maxIncome} $', style: TextStyle(color: Colors.grey.shade600)),
            const SizedBox(height:8),
            Row(mainAxisAlignment: MainAxisAlignment.end, children: [
              TextButton(onPressed: ()=>openKeysEditor(p), child: const Text('⚙️ إدارة المفاتيح')),
              const SizedBox(width:8),
              ElevatedButton(onPressed: () async {
                final keys = await loadKeys(p.id);
                final missing = p.keysRequired.where((k)=> !(keys.containsKey(k) && keys[k]!.length>5)).toList();
                if (missing.isNotEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('مفاتيح ناقصة: ${missing.join(', ')}')));
                } else {
                  p.status='running';
                  setState((){});
                }
              }, child: const Text('▶️ تشغيل الآن')),
            ])
          ])));
        }))
      ])),
    );
  }
}
