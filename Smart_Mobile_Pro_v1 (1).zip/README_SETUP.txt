Smart Mobile Pro - APK package (v1)
==================================

This package contains a Flutter prototype app for Smart Mobile Pro (Light Mode).
It stores API keys locally using flutter_secure_storage and provides the UI to manage and run projects.

Contents:
- pubspec.yaml
- lib/main.dart
- config_template.json
- README_SETUP.txt

How to build APK (recommended: on PC with Flutter SDK):
1) Install Flutter SDK: https://flutter.dev/docs/get-started/install
2) Extract this folder into a working directory.
3) From terminal run: flutter pub get
4) Build debug APK: flutter build apk --debug
   or release APK: flutter build apk --release
5) Transfer the generated APK from build/app/outputs/flutter-apk/app-release.apk to your phone and install.

Alternative: Use GitHub Actions or Codemagic to build remotely (recommended if you don't want to install Flutter locally).
I can help create the GitHub Actions workflow for automatic builds if you want.

App usage on phone:
- Install APK, open app.
- Use 'إدارة المفاتيح' to paste API keys per project (or import JSON).
- Press 'تشغيل الكل' to start; app will check keys and set projects to 'running' if ready.
- For Telegram alerts: you must enter TELEGRAM_BOT_TOKEN in the relevant project's keys and set up a bot/chat id.

Security:
- Keys are stored via flutter_secure_storage (Android Keystore).
- Do NOT share your keys.

Next steps I can do for you:
- Provide GitHub Actions YAML to auto-build APK on commit.
- Build a signed release APK if you give me keystore or want instructions to create one.
- Add features: Telegram alerts integration, background scheduler (WorkManager), Google Sheet sync.
